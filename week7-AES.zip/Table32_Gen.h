#pragma once

void AES32_Enc_Table_generation();
void AES32_Dec_Table_generation();
