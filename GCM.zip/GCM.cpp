﻿// GCM.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//

#include <iostream>
#include <fstream>
#include "AES32.h"
using namespace std;
typedef unsigned char byte;

//=(from CAVS.cpp)============================

bool isHex(char ch) {
	return ((ch >= '0') && (ch <= '9')) ||
		((ch >= 'A') && (ch <= 'F')) ||
		((ch >= 'a') && (ch <= 'f'));
}

// '8' --> 8,   'd' --> 13, 'g' --> error!
// 입력 ch : {0,1,...,9, A, .. ,F, a, ... , f}
byte Hex2Digit(char ch) {
	if (!isHex(ch)) {
		cout << ch << " is not a hex value." << endl;
		return -1; //의미없는 출력
	}
	if ((ch >= '0') && (ch <= '9')) {
		return  ch - '0'; // 예: '7' - '4' = 3
	}
	else if ((ch >= 'A') && (ch <= 'F')) {
		return ch - 'A' + 10;
	}
	else if ((ch >= 'a') && (ch <= 'f')) {
		return ch - 'a' + 10;
	}
	cout << "Unknown error." << endl;
	return -1;
}

// "8d" --> 8d = 8*16 + d
byte Hex2Byte(const char h[2]) {
	byte upper, lower;
	upper = h[0];
	lower = h[1];
	if ((!isHex(upper)) || (!isHex(lower))) {
		cout << "Hex Error" << endl;
		return -1;
	}
	return Hex2Digit(upper) * 16 + Hex2Digit(lower);
}

// "8d2e60365f17c7df1040d7501b4a7b5a" --> {8d, 2e, ... , 5a}
void Hex2Array(const char hex_str[], int hex_len, byte barr[]) {
	char h[2];
	byte b_value;
	for (int i = 0; i < hex_len / 2; i++) {
		h[0] = hex_str[2 * i];
		h[1] = hex_str[2 * i + 1];
		b_value = Hex2Byte(h);
		barr[i] = b_value;
	}
}

void print_b_array(byte b_arr[], int len, const char* pStr = nullptr) {
	if (pStr != nullptr) {
		printf("%s = ", pStr);
	}
	for (int i = 0; i < len; i++) {
		printf("%02x ", b_arr[i]);
	}
	printf("\n");
}

void copy_b_array(byte src[], int len, byte dest[]) {
	for (int i = 0; i < len; i++) {
		dest[i] = src[i];
	}
}

void xor_b_array(byte data[], int len, byte xor_arr[]) {
	for (int i = 0; i < len; i++) {
		data[i] ^= xor_arr[i];
	}
}

void hex_string_test() {
	const char* hex_string = "8d2e60365f17c7df1040d7501b4a7b5a";
	byte b[16];
	Hex2Array(hex_string, 32, b);
	print_b_array(b, 16, "KEY");
}

//=(from File_Enc_CBC.cpp)============================
// state[16]를 xor_value[]와 XOR 하여 업데이트
void XOR_state(byte state[16], byte xor_value[16]) {
	for (int i = 0; i < 16; i++) {
		state[i] ^= xor_value[i];
	}
}

// state[16]를 복사하기
void Copy_state(byte src[16], byte dest[16]) {
	for (int i = 0; i < 16; i++) {
		dest[i] = src[i];
	}
}

//===(Week 13)=========================================
// counter: (msb)  c[0] c[1] ... c[15] (lsb)
void counter_inc(byte counter[16]) {
	for (int i = 15; i >= 0; i--) { // c[15] --> c[0]
		if (counter[i] != 0xff) { //자리올림 없음
			counter[i]++;
			break; // for-loop를 벗어남
		}
		else { // 0xff --> 0x00, 자리올림
			counter[i] = 0x00;
		}
	}
}

//===========================================
// CT[] 암호문을 위한 메모리는 미리 확보하고 호출해야 함
void AES_CTR(byte PT[], int pt_len, byte key[16], byte CTR[16], byte CT[]) {
	int num_blocks, remainder;
	num_blocks = pt_len / 16; 
	remainder = pt_len - num_blocks * 16;

	byte pt[16], ctr_ct[16];
	u32 rk[11][4];
	byte current_ctr[16];

	AES32_Enc_KeySchedule(key, rk);

	Copy_state(CTR, current_ctr);
	for (int i = 0; i < num_blocks; i++) {
		for (int j = 0; j < 16; j++) pt[j] = PT[i * 16 + j];
		AES32_Encrypt(current_ctr, rk, ctr_ct);
		XOR_state(pt, ctr_ct); //pt가 암호문
		for (int j = 0; j < 16; j++) CT[i * 16 + j] = pt[j];
		counter_inc(current_ctr);
	}
	AES32_Encrypt(current_ctr, rk, ctr_ct);
	for (int i = 0; i < remainder; i++) {
		pt[i] = PT[16 * num_blocks + i];
		pt[i] ^= ctr_ct[i];
		CT[16 * num_blocks + i] = pt[i];
	}
}

//== (GHASH)====
// GF(2^128)의 xtime(), m(x) = x^128 + x^7 + x^2 + x + 1 (x^128 --> x^7 + x^2 + x + 1)
// 비트순서: (lsb) p[0] p[1] .... p[15](msb)
// 1+x+x^2+x^7 = 1110 0001 0000000000000...0
// p(x) * x  = (p0 + p1*x + p2*x^2 + ... + p127*x^127)*x
//           = p0*x + p1*x^2 + ... + p127*x^128
//           = p0*x + p1*x^2 + ... + p127*(x^7+x^2+x+1)          
//           = [0, p0, p1, ... , p126] xor p127*[1110 0001 000....]
void GF128_xtime(byte p[16]) { 
	byte msb = p[15] & 0x01;
	for (int i = 15; i > 0; i--) {
		// [  ....a] [bcde fghi] ==> [0bcd efgh] | [a000 0000] = [abcd efgh]
		p[i] = (p[i] >> 1) | (p[i - 1] << 7);
	}
	p[0] >>= 1; // [bcde fghi] ==> [0bcd efgh] 
	if (msb != 0) {
		p[0] ^= 0b11100001; //0xE1
	}
}

//== (GHASH) =====
// GF(2^128) 곱셈: p*q -> p
// p(x), q(x) = q0 + q1*x + q2*x^2 + ... + q127*x^127
// p(x)*q(x) = p(x)*(q0 + q1*x + q2*x^2 + ... + q127*x^127)
//     = q0*p(x) + q1*x*p(x) + q2*x^2*p(x) + ... + q127*x^127*p(x)
void GF128_mul(byte p[16], byte q[16]) {
	byte z[16] = { 0, };
	for (int i = 0; i < 16; i++) {
		for (int j = 0; j < 8; j++) { // q(x)의 계수를 하나씩
			if (q[i] & (1 << (7 - j))) {
				for (int k = 0; k < 16; k++) z[k] ^= p[k];
			}
			GF128_xtime(p);
		}
	}
	for (int k = 0; k < 16; k++) p[k] = z[k];
}

// (GHASH)====
// msg[] (128비트의 배수 길이만 가능)
// msg_blocks : 128비트 블록의 개수 
// H[]: GF(2^128)의 다항식 H = AES(0, Key)를 입력으로 준비할 예정임
// tag[]: 128비트 출력
void GHASH(byte msg[], int msg_blocks, byte H[16], byte tag[16]) {
	byte x[16];
	byte out[16] = { 0, };
	for (int i = 0; i < msg_blocks; i++) {
		for (int j = 0; j < 16; j++) x[j] = msg[i * 16 + j]; //입력블록
		XOR_state(out, x); // xor 결과는 out에 저장
		GF128_mul(out, H); // out <-- out*H
	}
	for (int j = 0; j < 16; j++) tag[j] = out[j];
}

//(GCM mode)====
// PT[]:평문,  pt_len(평문의 바이트수), CTR[]:카운터, 
// key[]:암호키, A[]:인증용추가입력,
// CT[]: 암호문(CTR_mode), tag[]:인증용 태그
// CT[] 암호문을 위한 메모리는 미리 확보하고 호출해야 함
void AES_GCM(byte PT[], int pt_len, byte CTR[16], byte key[16],
	byte A[], int A_len, byte CT[], byte tag[16]) { // week13에 tag[] 추가
	u32 rk[11][4];
	long long int Alen, Clen;
	Alen = (long long int)A_len * 8;
	Clen = (long long int)pt_len * 8;


	byte first_block[16] = { 0, };
	byte last_block[16];
	if (A_len > 0) { // A_len = 0,1,2,..., 16 (바이트)
		for (int j = 0; j < A_len; j++) first_block[j] = A[j];
	}
	for (int j = 0; j < 8; j++) { // last_block = [Alen||Clen]
		last_block[j] = (Alen >> (8 * (7 - j))) & 0xff;
		last_block[8+j] = (Clen >> (8 * (7 - j))) & 0xff;
	}

	// 여기부터 14주차 코딩시작
	byte H[16]; // H = AES(0,key)
	byte Y[16]; // Y = AES(ctr, key)
	byte Zero[16] = { 0, }; // 제로 벡터
	byte CTR1[16]; // CTR암호화를 위한 카운터
	AES32_Enc_KeySchedule(key, rk);
	AES32_Encrypt(CTR, rk, Y);
	AES32_Encrypt(Zero, rk, H);

	// 입력받은 CTR[]이 함수실행 후 변화하지 않도록 복사하여 사용함
	Copy_state(CTR, CTR1); //CTR --> CTR1 복사
	counter_inc(CTR1);
	AES_CTR(PT, pt_len, key, CTR1, CT);

	int msg_len; // GHASH에 넣을 메시지의 바이트 수
	int remainder; // 암호문에 필요한 패딩 바이트 수
	// PT[]: (1) 16의 배수이면, msg_len = pt_len + 2*16
	// PT[]: (2) 16의 배수가 아니면, msg_len = pt_len + 패딩 + 2*16
	msg_len = (pt_len % 16) == 0 ? pt_len + 2 * 16 : (pt_len / 16) * 16 + 3 * 16;
	remainder = (pt_len % 16) == 0 ? 0 : 16 - (pt_len % 16);
	
	byte* MSG; // GHASH에 넣을 메시지
	MSG = (byte*)malloc(msg_len); //16의 배수
	for (int i = 0; i < 16; i++) MSG[i] = first_block[i];
	for (int i = 0; i < pt_len; i++) MSG[16 + i] = CT[i];
	for (int i = 0; i < remainder; i++) MSG[16 + pt_len + i] = 0x00;
	for (int i = 0; i < 16; i++) MSG[16 + pt_len + remainder + i] = last_block[i];

	//(DEBUG)
	printf("MSG =");
	for (int i = 0; i < msg_len; i++) {
		printf("%02x", MSG[i]);
		if ((i % 16) == 15) printf(" ");
	}
	printf("\n");

	GHASH(MSG, msg_len / 16, H, tag);
	XOR_state(tag, Y);

}

//=====================
void AES_CTR_testvector() {
	const char* hex_key = "2b7e151628aed2a6abf7158809cf4f3c";
	const char* hex_iv = "f0f1f2f3f4f5f6f7f8f9fafbfcfdfeff";
	const char* hex_pt = "6bc1bee22e409f96e93d7e117393172a";
	const char* hex_ct = "874d6191b620e3261bef6864990db6ce";

	byte key[16], iv[16], pt[16], ct[16];

	Hex2Array(hex_key, 32, key);
	Hex2Array(hex_iv, 32, iv);
	Hex2Array(hex_pt, 32, pt);

	printf("TestVector-CTR... \n");

	AES_CTR(pt, 16, key, iv, ct);

	print_b_array(ct, 16, "ct");
}


void AES_GCM_testvector1() {
	/*
	Count = 0
	Key = 11754cd72aec309bf52f7687212e8957
	IV = 3c819d9a9bed087615030b65
	PT = 
	AAD = 
	CT = 
	Tag = 250327c674aaf477aef2675748cf6971
	*/
	const char* hex_key = "11754cd72aec309bf52f7687212e8957";
	const char* hex_iv = "3c819d9a9bed087615030b65";
	const char* hex_pt = "";
	const char* hex_aad = "";
	const char* hex_ct = "";
	const char* hex_tag = "250327c674aaf477aef2675748cf6971";
	

	byte key[16], iv[16], pt[16], ct[16], aad[16], tag[16];

	Hex2Array(hex_key, 32, key);
	Hex2Array(hex_iv, 24, iv);  //96비트
	
	printf("TestVector-GCM... \n");

	// CTR = IV(96bits) || 00...01 (32bits)
	byte CTR[16] = { 0, };
	for (int i = 0; i < 12; i++) CTR[i] = iv[i];
	CTR[15] = 0x01; 

	AES_GCM(pt, 0, CTR, key, aad, 0, ct, tag);

	print_b_array(tag, 16, "(calculated) tag = ");
	printf("(expected) tag = %s", hex_tag);
}

void AES_GCM_testvector2() {
	/*
	[Keylen = 128]
	[IVlen = 96]
	[PTlen = 0]
	[AADlen = 128]
	[Taglen = 128]
	
	Key = 77be63708971c4e240d1cb79e8d77feb
	IV = e0e00f19fed7ba0136a797f3
	PT = 
	AAD = 7a43ec1d9c0a5a78a0b16533a6213cab
	CT = 
	Tag = 209fcc8d3675ed938e9c7166709dd946
	*/
	const char* hex_key = "77be63708971c4e240d1cb79e8d77feb";
	const char* hex_iv = "e0e00f19fed7ba0136a797f3";
	const char* hex_pt = "";
	const char* hex_aad = "7a43ec1d9c0a5a78a0b16533a6213cab";
	const char* hex_ct = "";
	const char* hex_tag = "209fcc8d3675ed938e9c7166709dd946";


	byte key[16], iv[16], pt[16], ct[16], aad[16], tag[16];

	Hex2Array(hex_key, 32, key);
	Hex2Array(hex_aad, 32, aad);
	Hex2Array(hex_iv, 24, iv);  //96비트

	printf("TestVector-GCM... \n");

	// CTR = IV(96bits) || 00...01 (32bits)
	byte CTR[16] = { 0, };
	for (int i = 0; i < 12; i++) CTR[i] = iv[i];
	CTR[15] = 0x01;

	AES_GCM(pt, 0, CTR, key, aad, 16, ct, tag);

	print_b_array(tag, 16, "(calculated) tag = ");
	printf("(expected) tag = %s", hex_tag);
}
void AES_GCM_testvector3() {
	/*
	[Keylen = 128]
	[IVlen = 96]
	[PTlen = 128]
	[AADlen = 0]
	[Taglen = 128]

	Key = 7fddb57453c241d03efbed3ac44e371c
	IV = ee283a3fc75575e33efd4887
	PT = d5de42b461646c255c87bd2962d3b9a2
	AAD = 
	CT = 2ccda4a5415cb91e135c2a0f78c9b2fd
	Tag = b36d1df9b9d5e596f83e8b7f52971cb3
	*/
	const char* hex_key = "7fddb57453c241d03efbed3ac44e371c";
	const char* hex_iv = "ee283a3fc75575e33efd4887";
	const char* hex_pt = "d5de42b461646c255c87bd2962d3b9a2";
	const char* hex_aad = "";
	const char* hex_ct = "2ccda4a5415cb91e135c2a0f78c9b2fd";
	const char* hex_tag = "b36d1df9b9d5e596f83e8b7f52971cb3";


	byte key[16], iv[16], pt[16], ct[16], aad[16], tag[16];

	Hex2Array(hex_key, 32, key);
	Hex2Array(hex_iv, 24, iv);  //96비트
	Hex2Array(hex_pt, 32, pt);
	
	printf("TestVector-GCM... \n");

	// CTR = IV(96bits) || 00...01 (32bits)
	byte CTR[16] = { 0, };
	for (int i = 0; i < 12; i++) CTR[i] = iv[i];
	CTR[15] = 0x01;

	AES_GCM(pt, 16, CTR, key, aad, 0, ct, tag);

	print_b_array(ct, 16, "(calculated) ct = ");
	printf("(expected) ct = %s\n", hex_ct);
	print_b_array(tag, 16, "(calculated) tag = ");
	printf("(expected) tag = %s\n", hex_tag);
}

void AES_GCM_testvector4() {
	/*
	[Keylen = 128]
	[IVlen = 96]
	[PTlen = 128]
	[AADlen = 128]
	[Taglen = 128]

	Count = 0
	Key = c939cc13397c1d37de6ae0e1cb7c423c
	IV = b3d8cc017cbb89b39e0f67e2
	PT = c3b3c41f113a31b73d9a5cd432103069
	AAD = 24825602bd12a984e0092d3e448eda5f
	CT = 93fe7d9e9bfd10348a5606e5cafa7354
	Tag = 0032a1dc85f1c9786925a2e71d8272dd
	*/
	const char* hex_key = "c939cc13397c1d37de6ae0e1cb7c423c";
	const char* hex_iv = "b3d8cc017cbb89b39e0f67e2";
	const char* hex_pt = "c3b3c41f113a31b73d9a5cd432103069";
	const char* hex_aad = "24825602bd12a984e0092d3e448eda5f";
	const char* hex_ct = "93fe7d9e9bfd10348a5606e5cafa7354";
	const char* hex_tag = "0032a1dc85f1c9786925a2e71d8272dd";


	byte key[16], iv[16], pt[16], ct[16], aad[16], tag[16];

	Hex2Array(hex_key, 32, key);
	Hex2Array(hex_iv, 24, iv);  //96비트
	Hex2Array(hex_pt, 32, pt);
	Hex2Array(hex_aad, 32, aad);

	printf("TestVector-GCM... \n");

	// CTR = IV(96bits) || 00...01 (32bits)
	byte CTR[16] = { 0, };
	for (int i = 0; i < 12; i++) CTR[i] = iv[i];
	CTR[15] = 0x01;

	AES_GCM(pt, 16, CTR, key, aad, 16, ct, tag);

	print_b_array(ct, 16, "(calculated) ct");
	printf("(expected) ct = %s\n", hex_ct);
	print_b_array(tag, 16, "(calculated) tag");
	printf("(expected) tag = %s\n", hex_tag);
}

//===========================================
int main()
{
	AES_GCM_testvector4();
}

